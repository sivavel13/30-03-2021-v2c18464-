package RepeatFinding;

import java.util.HashMap;

public class RepeatFinding {
	
	public static void main(String[] args) {
		
		count("happy");
		count("mammy");
	}
	
	private static void count(String input ) {
		
		HashMap<Character, Integer>map=new HashMap<>();
		
		
		for (int i = 0; i < input.length(); i++) {
			char charAt = input.charAt(i);
			
			if (map.containsKey(charAt)) {
				
				map.put(charAt, map.get(charAt)+1);
				
			}
			else {
				map.put(charAt, 1);
		}
			
		}	
		System.out.println(map);
	}	

}

