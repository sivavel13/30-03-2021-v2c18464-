package TypeCastingDemo2;

public class TypeCastingDemo2 {

	public static void main(String[] args) {
		
		//Normal and easy way
		long l1 = 10;		
		int i1 = (int)l1;		
		System.out.println(i1);
		
		int i2 = 100;
		long l2 =(long)i2;
		System.out.println(l2);
		
		long l3 = Long.valueOf(i2); 	//using valueof method
		System.out.println(l3);
		
		double e = 200;
		int f = (int)e;
		System.out.println(f);
		
		String s1 = "True";
		Boolean b1 = Boolean.parseBoolean(s1);
		System.out.println(b1);
		 
		Boolean b2 = Boolean.valueOf(s1);  //using valueof method
		System.out.println(b2);
		
		String s2 = "False";
		Boolean b3 = Boolean.parseBoolean(s2);
		System.out.println(b3);	
	}

}


